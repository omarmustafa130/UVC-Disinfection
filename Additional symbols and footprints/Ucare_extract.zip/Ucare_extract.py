from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
import pandas as pd
import os
import time
from concurrent.futures import ThreadPoolExecutor

# Configure Chrome options for headless mode
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--disable-logging")
chrome_options.add_argument("--log-level=3")

# List of names to process
names_batch = [
    "Maxamed", "Mohamad", "Mohammed", "Axmed", "Cabdi", "Xasan", "Hussein", "Hussien", "Husein", "Yusuf", "Yuusuf", "Nur", "Nor", "Osman", "Aden", "Farah",
    "Warsame", "Sharif", "Ibrahim", "Mohamud", "Abukar", "Bashir", "Ismail", "Elmi", "Khalif", "Daud",
    "Sheikh", "Mahad", "Mursal", "Rage", "Bile", "Shire", "Isse"
]

# Function to create a new Chrome driver
def create_driver():
    return webdriver.Chrome(options=chrome_options)

def process_name_all_years(name):
    driver = create_driver()
    try:
        print(f"Processing all years for Name: {name}")
        driver.get("https://provider.ucare.org/pages/login.aspx")

        # Input username and password
        username = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "ctl00_SPWebPartManager1_g_bc96337e_dcf6_4453_8de3_e8b322788aea_ctl00_UserName"))
        )
        username.send_keys("SHServIces")

        password = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "ctl00_SPWebPartManager1_g_bc96337e_dcf6_4453_8de3_e8b322788aea_ctl00_Password"))
        )
        password.send_keys("K@lebkody1")

        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "ctl00_SPWebPartManager1_g_bc96337e_dcf6_4453_8de3_e8b322788aea_ctl00_LoginButton"))
        )
        login_button.click()
        time.sleep(5)

        for yr in range(1950, 2007):
            print(f"Extracting info for Year {yr} - Name: {name}")
            driver.get("https://provider.ucare.org/Member%20Information/Pages/eligibility.aspx")

            last_name_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "ctl00_SPWebPartManager1_g_0720f483_9d8a_4be8_9135_30134172db3e_tbLastName"))
            )
            last_name_field.send_keys(name)

            dob_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "ctl00_SPWebPartManager1_g_0720f483_9d8a_4be8_9135_30134172db3e_tbDobField"))
            )
            dob_field.send_keys(f"01/01/{yr}")

            find_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.NAME, "ctl00$SPWebPartManager1$g_0720f483_9d8a_4be8_9135_30134172db3e$ctl06"))
            )
            find_button.click()

            try:
                eligibility = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, "//h2[contains(text(),'Member is')]")
                )).text
            except:
                eligibility = 'Not Available'

            div_elements = WebDriverWait(driver, 10).until(
                EC.presence_of_all_elements_located((By.CLASS_NAME, 'displayLabelwContent'))
            )

            member_name, member_number, pmi_number = '', '', ''
            address_1, address_2, city, state, zip_code = '', '', '', '', ''
            dob, phone = '', ''

            for div in div_elements:
                try:
                    label_text = div.find_element(By.CLASS_NAME, 'dataLabel').text.strip()
                    data_text = div.find_element(By.CLASS_NAME, 'dataContent').text.strip()

                    if 'Member Name' in label_text:
                        member_name = data_text
                    elif 'Member Number' in label_text:
                        member_number = data_text
                    elif 'PMI' in label_text:
                        pmi_number = data_text
                    elif 'Address 1' in label_text:
                        address_1 = data_text
                    elif 'Address 2' in label_text:
                        address_2 = data_text
                    elif 'City' in label_text:
                        city = data_text
                    elif 'State' in label_text:
                        state = data_text
                    elif 'Zip' in label_text:
                        zip_code = data_text
                    elif 'Date of Birth' in label_text:
                        dob = data_text
                    elif 'Phone' in label_text:
                        phone = data_text
                except Exception as e:
                    print(f"Error processing div: {e}")

            new_data = pd.DataFrame({
                'Year': [yr],
                'Eligibility': [eligibility],
                'Member Name': [member_name],
                'Member Number': [member_number],
                'PMI Number': [pmi_number],
                'Address 1': [address_1],
                'Address 2': [address_2],
                'City': [city],
                'State': [state],
                'Zip Code': [zip_code],
                'Date of Birth': [dob],
                'Phone': [phone]
            })

            csv_file_path = f'output_{yr}_{name}.csv'
            if os.path.exists(csv_file_path):
                existing_data = pd.read_csv(csv_file_path, dtype=str)
                updated_data = pd.concat([existing_data, new_data], ignore_index=True)
                updated_data.to_csv(csv_file_path, index=False)
            else:
                new_data.to_csv(csv_file_path, index=False)

            time.sleep(2)
            print(f"Finished year {yr} for name {name}")
    finally:
        driver.quit()

def main():
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(process_name_all_years, name) for name in names_batch]
        for future in futures:
            future.result()

if __name__ == "__main__":
    main()
